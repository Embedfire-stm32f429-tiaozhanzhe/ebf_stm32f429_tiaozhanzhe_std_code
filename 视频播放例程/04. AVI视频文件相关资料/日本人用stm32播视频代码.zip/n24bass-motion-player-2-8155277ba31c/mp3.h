/*
 * mp3.h
 *
 *  Created on: 2012/03/25
 *      Author: Tonsuke
 */

#ifndef MP3_H_
#define MP3_H_

#include "stm32f4xx_conf.h"


extern int PlayMP3(int id);

#endif /* MP3_H_ */
